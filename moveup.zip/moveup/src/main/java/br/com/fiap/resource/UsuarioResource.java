package br.com.fiap.resource;

import br.com.fiap.bo.UsuarioBO;
import br.com.fiap.to.UsuarioTO;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/moveup/usuario")
public class UsuarioResource {

    private UsuarioBO usuarioBO = new UsuarioBO();

    @PostMapping
    public ResponseEntity<?> save(@RequestBody @Valid UsuarioTO usuario) {
        try {
            UsuarioTO resultado = usuarioBO.save(usuario);
            return ResponseEntity.status(HttpStatus.CREATED).body(resultado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao salvar usuário");
        }
    }

    @GetMapping
    public ResponseEntity<List<UsuarioTO>> findAll(){
        List<UsuarioTO> usuarios = usuarioBO.findAll();
        if (usuarios != null){
            return  ResponseEntity.status(HttpStatus.OK).body(usuarios);
        }else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(usuarios);
        }
    }

    @GetMapping("/{idUsuario}")
    public ResponseEntity<?> findById(@PathVariable Integer idUsuario){
        UsuarioTO usuario = usuarioBO.findById(idUsuario);
        if (usuario != null){
            return ResponseEntity.status(HttpStatus.OK).body(usuario);
        }else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuário não encontrado!");
        }
    }

    @DeleteMapping ("/{idUsuario}")
    public ResponseEntity<String> delete(@PathVariable Integer idUsuario){
        if (usuarioBO.delete(idUsuario)){
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Usuário deletado com sucesso!");
        }else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuário não encontrado!");
        }
    }

    @PutMapping("/{idUsuario}")
    public ResponseEntity<?> update(@PathVariable Integer idUsuario, @RequestBody @Valid UsuarioTO usuario){
        try{
            usuario.setIdUsuario(idUsuario);
            UsuarioTO resultado = usuarioBO.update(usuario);
            return ResponseEntity.status(HttpStatus.CREATED).body(resultado);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao atualizar usuário");
        }
    }

}
